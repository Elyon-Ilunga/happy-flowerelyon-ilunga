#ask for a number
num = int(input('Enter a number:'))

#initialize counter
count = 0

#multiply through the numbers 0 to 10 with user's number
while (count <=10):
  print(str(count) + ' * ' + str(num) + ' = ' + str(count * num))
  count = count + 1